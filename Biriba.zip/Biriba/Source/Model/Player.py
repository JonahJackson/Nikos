class Player(object):
	def __init__(self):
		self.hand = []