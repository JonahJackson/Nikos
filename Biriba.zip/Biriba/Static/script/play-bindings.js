window.onload = function() {
	loadScreen();
};